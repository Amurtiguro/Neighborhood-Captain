package com.ijw.notice.vo;

public class NoticeVO {
	
	//알림 
	private String nnum;
	private String nmnum;
	private String nsort;
	private String ninfo;
	private String nurl;
	private String ndelyn;
	private String nsenddate;
	private String mnum;
	// 
	private String mid;
	
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getNnum() {
		return nnum;
	}
	public void setNnum(String nnum) {
		this.nnum = nnum;
	}
	public String getNmnum() {
		return nmnum;
	}
	public void setNmnum(String nmnum) {
		this.nmnum = nmnum;
	}
	public String getNsort() {
		return nsort;
	}
	public void setNsort(String nsort) {
		this.nsort = nsort;
	}
	public String getNinfo() {
		return ninfo;
	}
	public void setNinfo(String ninfo) {
		this.ninfo = ninfo;
	}
	public String getNurl() {
		return nurl;
	}
	public void setNurl(String nurl) {
		this.nurl = nurl;
	}
	public String getNdelyn() {
		return ndelyn;
	}
	public void setNdelyn(String ndelyn) {
		this.ndelyn = ndelyn;
	}
	public String getNsenddate() {
		return nsenddate;
	}
	public void setNsenddate(String nsenddate) {
		this.nsenddate = nsenddate;
	}
	public String getMnum() {
		return mnum;
	}
	public void setMnum(String mnum) {
		this.mnum = mnum;
	}

}
