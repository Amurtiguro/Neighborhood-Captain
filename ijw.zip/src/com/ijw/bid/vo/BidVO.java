package com.ijw.bid.vo;

public class BidVO {
	
	//�엯李� 
	private String bnum;
	private String bprice;
	private String bwinyn;
	private String bdate;
	private String anum;
	private String mnum;
	
	public String getBnum() {
		return bnum;
	}
	public void setBnum(String bnum) {
		this.bnum = bnum;
	}
	public String getBprice() {
		return bprice;
	}
	public void setBprice(String bprice) {
		this.bprice = bprice;
	}
	public String getBwinyn() {
		return bwinyn;
	}
	public void setBwinyn(String bwinyn) {
		this.bwinyn = bwinyn;
	}
	public String getBdate() {
		return bdate;
	}
	public void setBdate(String bdate) {
		this.bdate = bdate;
	}
	public String getAnum() {
		return anum;
	}
	public void setAnum(String anum) {
		this.anum = anum;
	}
	public String getMnum() {
		return mnum;
	}
	public void setMnum(String mnum) {
		this.mnum = mnum;
	}
	
	
}
