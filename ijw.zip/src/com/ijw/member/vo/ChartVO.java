package com.ijw.member.vo;

public class ChartVO {

	private String selectYear; // 년도를 받기위한 vo
	private String cgNum;
	
	
	//DB칼럼을 맞추기위한 VO
	private String saJaCount1;//사자카운트
	private String panDaCount1;//판다 카운트
	private String AuctCount1;//경매카운트
	private String totalCount1;//총계카운트
	
	private String saJaCount2;//사자카운트
	private String panDaCount2;//판다 카운트
	private String AuctCount2;//경매카운트
	private String totalCount2;//총계카운트
	
	private String saJaCount3;//사자카운트
	private String panDaCount3;//판다 카운트
	private String AuctCount3;//경매카운트
	private String totalCount3;//총계카운트
	
	private String saJaCount4;//사자카운트
	private String panDaCount4;//판다 카운트
	private String AuctCount4;//경매카운트
	private String totalCount4;//총계카운트
	
	public String getSelectYear() {
		return selectYear;
	}
	public void setSelectYear(String selectYear) {
		this.selectYear = selectYear;
	}
	public String getCgNum() {
		return cgNum;
	}
	public void setCgNum(String cgNum) {
		this.cgNum = cgNum;
	}
	
	public String getSaJaCount1() {
		return saJaCount1;
	}
	public void setSaJaCount1(String saJaCount1) {
		this.saJaCount1 = saJaCount1;
	}
	public String getPanDaCount1() {
		return panDaCount1;
	}
	public void setPanDaCount1(String panDaCount1) {
		this.panDaCount1 = panDaCount1;
	}
	public String getAuctCount1() {
		return AuctCount1;
	}
	public void setAuctCount1(String auctCount1) {
		AuctCount1 = auctCount1;
	}
	public String getTotalCount1() {
		return totalCount1;
	}
	public void setTotalCount1(String totalCount1) {
		this.totalCount1 = totalCount1;
	}
	public String getSaJaCount2() {
		return saJaCount2;
	}
	public void setSaJaCount2(String saJaCount2) {
		this.saJaCount2 = saJaCount2;
	}
	public String getPanDaCount2() {
		return panDaCount2;
	}
	public void setPanDaCount2(String panDaCount2) {
		this.panDaCount2 = panDaCount2;
	}
	public String getAuctCount2() {
		return AuctCount2;
	}
	public void setAuctCount2(String auctCount2) {
		AuctCount2 = auctCount2;
	}
	public String getTotalCount2() {
		return totalCount2;
	}
	public void setTotalCount2(String totalCount2) {
		this.totalCount2 = totalCount2;
	}
	public String getSaJaCount3() {
		return saJaCount3;
	}
	public void setSaJaCount3(String saJaCount3) {
		this.saJaCount3 = saJaCount3;
	}
	public String getPanDaCount3() {
		return panDaCount3;
	}
	public void setPanDaCount3(String panDaCount3) {
		this.panDaCount3 = panDaCount3;
	}
	public String getAuctCount3() {
		return AuctCount3;
	}
	public void setAuctCount3(String auctCount3) {
		AuctCount3 = auctCount3;
	}
	public String getTotalCount3() {
		return totalCount3;
	}
	public void setTotalCount3(String totalCount3) {
		this.totalCount3 = totalCount3;
	}
	public String getSaJaCount4() {
		return saJaCount4;
	}
	public void setSaJaCount4(String saJaCount4) {
		this.saJaCount4 = saJaCount4;
	}
	public String getPanDaCount4() {
		return panDaCount4;
	}
	public void setPanDaCount4(String panDaCount4) {
		this.panDaCount4 = panDaCount4;
	}
	public String getAuctCount4() {
		return AuctCount4;
	}
	public void setAuctCount4(String auctCount4) {
		AuctCount4 = auctCount4;
	}
	public String getTotalCount4() {
		return totalCount4;
	}
	public void setTotalCount4(String totalCount4) {
		this.totalCount4 = totalCount4;
	}
	
	

}
