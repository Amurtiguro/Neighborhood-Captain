package com.ijw.deal.service;

import com.ijw.deal.vo.DealVO;

public interface DealService {
	
	// 거래 신청. ===============================
	public int dealInsert(DealVO dvo);
}
