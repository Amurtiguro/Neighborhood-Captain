package com.ijw.deal.dao;

import com.ijw.deal.vo.DealVO;

public interface DealDao {

	// 거래 신청. ===============================
	public int dealInsert(DealVO dvo);
}
